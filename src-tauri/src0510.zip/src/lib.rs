mod audio;
mod autostart;
mod fullscreen_detect;
mod keyboard_hook;
mod screen_lock;
mod settings;
mod state;
mod tray;

use settings::{ForceMode, Settings};
use state::{AppStateEnum, AppTimer};
use std::sync::Mutex;
use std::os::windows::ffi::OsStrExt;
use tauri::{Emitter, Listener, Manager};

struct AppState {
    settings: Mutex<Settings>,
    timer: Mutex<AppTimer>,
    lock_manager: Mutex<screen_lock::LockScreenManager>,
}

#[tauri::command]
fn get_settings(state: tauri::State<'_, AppState>) -> Result<Settings, String> {
    state.settings.lock().map_err(|e| e.to_string()).map(|s| s.clone())
}

#[tauri::command]
fn save_settings(
    app: tauri::AppHandle,
    state: tauri::State<'_, AppState>,
    settings: Settings,
) -> Result<(), String> {
    settings::save_settings(&settings)?;
    {
        let mut current = state.settings.lock().map_err(|e| e.to_string())?;
        *current = settings.clone();
    }
    // Reset timer to apply new work interval
    {
        let mut timer = state.timer.lock().map_err(|e| e.to_string())?;
        timer.reset_work(settings.work_interval_minutes);
    }
    let _ = app.emit("settings_updated", ());
    Ok(())
}

#[tauri::command]
fn start_rest_now(app: tauri::AppHandle, state: tauri::State<'_, AppState>) -> Result<(), String> {
    let settings = state.settings.lock().map_err(|e| e.to_string())?.clone();
    let mut timer = state.timer.lock().map_err(|e| e.to_string())?;

    // Hide countdown window
    if let Some(window) = app.get_webview_window("countdown") {
        let _ = window.hide();
    }

    // Reset rest timer
    timer.reset_rest(settings.rest_duration_minutes);
    drop(timer);

    // Play break.mid
    let sounds_dir = audio::get_sounds_dir(&app);
    let break_path = format!("{}\\break.mid", sounds_dir);
    if let Err(e) = audio::play_midi(&break_path) {
        eprintln!("Audio error: {}", e);
    }

    // Lock all screens
    let mut lock_mgr = state.lock_manager.lock().map_err(|e| e.to_string())?;
    lock_mgr.lock_all_screens(&app)?;

    // Enable keyboard hook lock
    keyboard_hook::IS_LOCKED.store(true, std::sync::atomic::Ordering::Relaxed);

    Ok(())
}

#[tauri::command]
fn postpone_rest(state: tauri::State<'_, AppState>, minutes: u32) -> Result<(), String> {
    let settings = state.settings.lock().map_err(|e| e.to_string())?;
    let max = settings.max_postpone_count;
    drop(settings);

    let mut timer = state.timer.lock().map_err(|e| e.to_string())?;
    if !timer.postpone(minutes, max) {
        return Err("Postpone limit reached".to_string());
    }
    Ok(())
}

#[tauri::command]
fn set_always_on_top(app: tauri::AppHandle, top: bool) -> Result<(), String> {
    if let Some(window) = app.get_webview_window("countdown") {
        window.set_always_on_top(top).map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn open_settings_window(app: tauri::AppHandle) -> Result<(), String> {
    if let Some(win) = app.get_webview_window("settings") {
        let _ = win.show();
        let _ = win.set_focus();
    } else {
        tauri::WebviewWindowBuilder::new(
            &app,
            "settings",
            tauri::WebviewUrl::App("settings.html".into()),
        )
        .title("爱眼卫士 设置")
        .inner_size(400.0, 380.0)
        .center()
        .decorations(true)
        .resizable(false)
        .build()
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn unlock_screen(app: tauri::AppHandle, state: tauri::State<'_, AppState>) -> Result<(), String> {
    let settings = state.settings.lock().map_err(|e| e.to_string())?.clone();

    // Unlock all screens
    let mut lock_mgr = state.lock_manager.lock().map_err(|e| e.to_string())?;
    lock_mgr.unlock_all();
    drop(lock_mgr);

    // Disable keyboard hook lock
    keyboard_hook::IS_LOCKED.store(false, std::sync::atomic::Ordering::Relaxed);

    // Play unlock.mid
    let sounds_dir = audio::get_sounds_dir(&app);
    let unlock_path = format!("{}\\unlock.mid", sounds_dir);
    if let Err(e) = audio::play_midi(&unlock_path) {
        eprintln!("Audio error: {}", e);
    }

    // Reset work timer
    let mut timer = state.timer.lock().map_err(|e| e.to_string())?;
    timer.reset_work(settings.work_interval_minutes);
    drop(timer);

    // Show countdown window
    if let Some(window) = app.get_webview_window("countdown") {
        let _ = window.show();
    }

    Ok(())
}

#[tauri::command]
fn quit_app(app: tauri::AppHandle) {
    keyboard_hook::uninstall_hook();
    app.exit(0);
}

#[tauri::command]
fn get_autostart(_app: tauri::AppHandle) -> Result<bool, String> {
    Ok(autostart::is_autostart_enabled())
}

#[tauri::command]
fn set_autostart(_app: tauri::AppHandle, enabled: bool) -> Result<(), String> {
    let exe_path = std::env::current_exe()
        .map_err(|e| e.to_string())?
        .to_string_lossy()
        .to_string();
    autostart::set_autostart(enabled, &exe_path)
}

#[tauri::command]
fn confirm_dialog(message: String) -> Result<bool, String> {
    // Raw Win32 FFI to avoid windows crate version conflicts with Tauri
    extern "system" {
        fn MessageBoxW(hwnd: isize, lptext: *const u16, lpcaption: *const u16, utype: u32) -> i32;
    }
    const MB_YESNO: u32 = 0x00000004;
    const MB_ICONQUESTION: u32 = 0x00000020;
    const MB_TOPMOST: u32 = 0x00040000;
    const IDYES: i32 = 6;

    let msg_wide: Vec<u16> = std::ffi::OsStr::new(&message)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    let title_wide: Vec<u16> = std::ffi::OsStr::new("爱眼卫士")
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();
    unsafe {
        let result = MessageBoxW(
            0,
            msg_wide.as_ptr(),
            title_wide.as_ptr(),
            MB_YESNO | MB_ICONQUESTION | MB_TOPMOST,
        );
        Ok(result == IDYES)
    }
}

pub fn run() {
    let loaded_settings = settings::load_settings();
    let timer = AppTimer::new(loaded_settings.work_interval_minutes);

    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .manage(AppState {
            settings: Mutex::new(loaded_settings),
            timer: Mutex::new(timer),
            lock_manager: Mutex::new(screen_lock::LockScreenManager::new()),
        })
        .invoke_handler(tauri::generate_handler![
            get_settings,
            save_settings,
            start_rest_now,
            postpone_rest,
            set_always_on_top,
            open_settings_window,
            unlock_screen,
            quit_app,
            get_autostart,
            set_autostart,
            confirm_dialog,
        ])
        .setup(|app| {
            // Install keyboard hook
            keyboard_hook::install_hook().ok();

            // Create system tray
            tray::create_tray(app.handle())?;

            // Provide AppHandle for native lock windows
            screen_lock::set_app_handle(app.handle().clone());

            // Listen for unlock request from native lock windows
            let app_handle2 = app.handle().clone();
            app.listen("unlock_request", move |_| {
                let state = app_handle2.state::<AppState>();
                let settings = state.settings.lock().unwrap().clone();
                let mut lock_mgr = state.lock_manager.lock().unwrap();
                lock_mgr.unlock_all();
                drop(lock_mgr);
                keyboard_hook::IS_LOCKED.store(false, std::sync::atomic::Ordering::Relaxed);
                let sounds_dir = audio::get_sounds_dir(&app_handle2);
                let _ = audio::play_midi(&format!("{}\\unlock.mid", sounds_dir));
                let mut timer = state.timer.lock().unwrap();
                timer.reset_work(settings.work_interval_minutes);
                drop(timer);
                if let Some(window) = app_handle2.get_webview_window("countdown") {
                    let _ = window.show();
                }
            });

            // Create countdown window
            if app.get_webview_window("countdown").is_none() {
                let _countdown = tauri::WebviewWindowBuilder::new(
                    app,
                    "countdown",
                    tauri::WebviewUrl::App("index.html".into()),
                )
                .inner_size(180.0, 70.0)
                .decorations(false)
                .always_on_top(true)
                .skip_taskbar(true)
                .resizable(false)
                .title("EyeGuard")
                .build()?;

                // Position at top-right of primary monitor initially
                if let Some(monitor) = app.primary_monitor().ok().flatten() {
                    let size = monitor.size();
                    let scale = monitor.scale_factor();
                    let logical_width = size.width as f64 / scale;
                    let x = (logical_width - 400.0).max(0.0);
                    let _ = _countdown.set_position(tauri::LogicalPosition::new(x, 20.0));
                    // Lock the size to prevent WebView from expanding
                    let _ = _countdown.set_size(tauri::LogicalSize::new(180.0, 70.0));
                }
            }

            // Timer thread: 1-second ticks
            let app_handle = app.handle().clone();
            std::thread::spawn(move || {
                loop {
                    std::thread::sleep(std::time::Duration::from_secs(1));

                    let state = app_handle.state::<AppState>();
                    let settings = match state.settings.lock() {
                        Ok(s) => s.clone(),
                        Err(_) => continue,
                    };

                    // Bind lock result to variable to ensure proper drop order
                    let timer_lock = state.timer.lock();
                    if let Ok(mut timer) = timer_lock {
                        if timer.state == AppStateEnum::Working {
                            // Fullscreen detection - pause when fullscreen app is running
                            let is_fullscreen = fullscreen_detect::is_foreground_fullscreen();
                            if is_fullscreen && !timer.paused {
                                timer.paused = true;
                            } else if !is_fullscreen && timer.paused {
                                timer.paused = false;
                                timer.last_tick = std::time::Instant::now();
                            }

                            if let Some(remaining) = timer.tick() {
                                // Send tick event to countdown window
                                let payload = serde_json::json!({
                                    "remaining_secs": remaining,
                                    "total_secs": timer.total_secs,
                                    "postpone_count": timer.postpone_count,
                                    "max_postpone": settings.max_postpone_count,
                                });
                                let _ = app_handle.emit("tick", payload);

                                // 3-minute warning
                                if remaining <= 180 && remaining > 170 {
                                    let sounds_dir = audio::get_sounds_dir(&app_handle);
                                    let pre_path = format!("{}\\breakpre.mid", sounds_dir);
                                    if let Err(e) = audio::play_midi(&pre_path) {
                                        eprintln!("Audio error: {}", e);
                                    }
                                }

                                // Countdown reached zero -> start rest
                                if remaining == 0 {
                                    let s = settings.clone();
                                    drop(timer);
                                    start_rest_inline(&app_handle, &state, &s);
                                }
                            }
                        } else if timer.state == AppStateEnum::Resting {
                            if let Some(remaining) = timer.tick() {
                                let elapsed = timer.total_secs.saturating_sub(remaining);
                                let can_unlock = match settings.force_mode {
                                    ForceMode::None => true,
                                    ForceMode::Soft => elapsed >= 60,
                                    ForceMode::Hard => false,
                                };

                                // Update native lock windows instead of emitting WebView event
                                screen_lock::set_lock_state(remaining, can_unlock);

                                // Rest ended -> auto unlock
                                if remaining == 0 {
                                    let s = settings.clone();
                                    drop(timer);
                                    unlock_inline(&app_handle, &state, &s);
                                }
                            }
                        }
                    }
                }
            });

            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                if window.label() == "countdown" {
                    api.prevent_close();
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

// Inline implementations called from the timer thread
// These work directly with State references instead of trying to pass State as owned
fn start_rest_inline(app: &tauri::AppHandle, state: &tauri::State<'_, AppState>, settings: &Settings) {
    if let Some(window) = app.get_webview_window("countdown") {
        let _ = window.hide();
    }

    if let Ok(mut timer) = state.timer.lock() {
        timer.reset_rest(settings.rest_duration_minutes);
    }

    let sounds_dir = audio::get_sounds_dir(app);
    let break_path = format!("{}\\break.mid", sounds_dir);
    if let Err(e) = audio::play_midi(&break_path) {
        eprintln!("Audio error: {}", e);
    }

    if let Ok(mut lock_mgr) = state.lock_manager.lock() {
        let _ = lock_mgr.lock_all_screens(app);
    }

    keyboard_hook::IS_LOCKED.store(true, std::sync::atomic::Ordering::Relaxed);
}

fn unlock_inline(app: &tauri::AppHandle, state: &tauri::State<'_, AppState>, settings: &Settings) {
    if let Ok(mut lock_mgr) = state.lock_manager.lock() {
        lock_mgr.unlock_all();
    }

    keyboard_hook::IS_LOCKED.store(false, std::sync::atomic::Ordering::Relaxed);

    let sounds_dir = audio::get_sounds_dir(app);
    let unlock_path = format!("{}\\unlock.mid", sounds_dir);
    if let Err(e) = audio::play_midi(&unlock_path) {
        eprintln!("Audio error: {}", e);
    }

    if let Ok(mut timer) = state.timer.lock() {
        timer.reset_work(settings.work_interval_minutes);
    }

    if let Some(window) = app.get_webview_window("countdown") {
        let _ = window.show();
    }
}
