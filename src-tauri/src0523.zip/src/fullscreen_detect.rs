use windows::Win32::Foundation::*;
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::Win32::Graphics::Gdi::*;

pub fn is_foreground_fullscreen() -> bool {
    unsafe {
        let hwnd = GetForegroundWindow();
        if hwnd.0.is_null() {
            return false;
        }

        // Check if window is visible
        if !IsWindowVisible(hwnd).as_bool() {
            return false;
        }

        // Get foreground window rect
        let mut window_rect = RECT::default();
        if GetWindowRect(hwnd, &mut window_rect).is_err() {
            return false;
        }

        // Skip desktop and taskbar
        let shell_hwnd = GetShellWindow();
        let progman_hwnd = GetDesktopWindow();
        if hwnd == shell_hwnd || hwnd == progman_hwnd {
            return false;
        }

        let win_w = (window_rect.right - window_rect.left) as u32;
        let win_h = (window_rect.bottom - window_rect.top) as u32;

        // Get the monitor that contains the window
        let monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
        if monitor.0.is_null() {
            return false;
        }

        let mut monitor_info = MONITORINFO {
            cbSize: std::mem::size_of::<MONITORINFO>() as u32,
            rcMonitor: RECT::default(),
            rcWork: RECT::default(),
            dwFlags: 0,
        };

        if !GetMonitorInfoW(monitor, &mut monitor_info).as_bool() {
            return false;
        }

        let monitor_w = (monitor_info.rcMonitor.right - monitor_info.rcMonitor.left) as u32;
        let monitor_h = (monitor_info.rcMonitor.bottom - monitor_info.rcMonitor.top) as u32;

        // Size check: foreground window must match monitor resolution
        if !(win_w >= monitor_w && win_h >= monitor_h) {
            return false;
        }

        // Style check: a true fullscreen window has NO caption/title bar or thick frame.
        // Maximized windows have WS_CAPTION (title bar) or WS_THICKFRAME (resizable border),
        // so we exclude those.
        let style = GetWindowLongA(hwnd, GWL_STYLE) as u32;
        if (style & WS_CAPTION.0) == WS_CAPTION.0
            || (style & WS_THICKFRAME.0) == WS_THICKFRAME.0
        {
            return false; // Has chrome -> maximized, not fullscreen
        }

        true
    }
}
