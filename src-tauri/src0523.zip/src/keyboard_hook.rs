use windows::Win32::Foundation::*;
use windows::Win32::UI::WindowsAndMessaging::*;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;

/// Wrapper to make HHOOK Send+Sync (HHOOK is a raw pointer, which is not Send by default)
struct HookHandle(Option<HHOOK>);
unsafe impl Send for HookHandle {}
unsafe impl Sync for HookHandle {}

static HOOK_HANDLE: Mutex<HookHandle> = Mutex::new(HookHandle(None));
pub static IS_LOCKED: AtomicBool = AtomicBool::new(false);

/// Low-level keyboard hook procedure
/// When IS_LOCKED is true, blocks:
/// - Windows logo key (VK_LWIN=0x5B, VK_RWIN=0x5C)
/// - Alt+Tab
/// - Alt+F4
unsafe extern "system" fn keyboard_proc(
    code: i32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    if code >= 0 && IS_LOCKED.load(Ordering::Relaxed) {
        let kbd = &*(lparam.0 as *const KBDLLHOOKSTRUCT);
        let vk = kbd.vkCode;

        // Windows key
        if vk == 0x5B || vk == 0x5C {
            return LRESULT(1);
        }

        // Alt+Tab
        if vk == 0x09 {
            let alt_pressed = (kbd.flags & KBDLLHOOKSTRUCT_FLAGS(0x20)) == KBDLLHOOKSTRUCT_FLAGS(0x20);
            if alt_pressed {
                return LRESULT(1);
            }
        }

        // Alt+F4
        if vk == 0x73 {
            let alt_pressed = (kbd.flags & KBDLLHOOKSTRUCT_FLAGS(0x20)) == KBDLLHOOKSTRUCT_FLAGS(0x20);
            if alt_pressed {
                return LRESULT(1);
            }
        }
    }

    CallNextHookEx(HHOOK::default(), code, wparam, lparam)
}

pub fn install_hook() -> Result<(), String> {
    unsafe {
        let handle = SetWindowsHookExW(
            WH_KEYBOARD_LL,
            Some(keyboard_proc),
            HINSTANCE::default(),
            0,
        ).map_err(|e| format!("Failed to install keyboard hook: {}", e))?;

        let mut guard = HOOK_HANDLE.lock().map_err(|e| e.to_string())?;
        *guard = HookHandle(Some(handle));
    }
    Ok(())
}

pub fn uninstall_hook() {
    unsafe {
        if let Ok(mut guard) = HOOK_HANDLE.lock() {
            if let Some(handle) = guard.0.take() {
                let _ = UnhookWindowsHookEx(handle);
            }
        }
    }
}
