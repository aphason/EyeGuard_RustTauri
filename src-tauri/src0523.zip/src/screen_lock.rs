use std::collections::HashMap;
use std::sync::Mutex;
use std::os::windows::ffi::OsStrExt;
use windows::Win32::Foundation::*;
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::core::PCWSTR;

const LOCK_CLASS: &str = "EyeGuardLock";

// Shared state for all lock windows
static LOCK_REMAINING: Mutex<u32> = Mutex::new(0);
static LOCK_CAN_UNLOCK: Mutex<bool> = Mutex::new(false);

pub fn set_lock_state(remaining: u32, can_unlock: bool) {
    *LOCK_REMAINING.lock().unwrap() = remaining;
    *LOCK_CAN_UNLOCK.lock().unwrap() = can_unlock;
}

// Need AppHandle for unlock command. Set once during app init.
use std::sync::OnceLock;
static APP_HANDLE_FOR_LOCK: OnceLock<tauri::AppHandle> = OnceLock::new();

pub fn set_app_handle(handle: tauri::AppHandle) {
    let _ = APP_HANDLE_FOR_LOCK.set(handle);
}

pub struct LockScreenManager {
    lock_windows: HashMap<String, HWND>,
}

// HWND wraps *mut c_void which is not Send, but window handles are
// valid across threads on Windows.
unsafe impl Send for LockScreenManager {}

impl LockScreenManager {
    pub fn new() -> Self {
        unsafe {
            let hinstance = GetModuleHandleW(None).unwrap_or_default();
            let cn: Vec<u16> = std::ffi::OsStr::new(LOCK_CLASS)
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();
            let wc = WNDCLASSW {
                style: CS_HREDRAW | CS_VREDRAW,
                lpfnWndProc: Some(lock_window_proc),
                hInstance: HINSTANCE(hinstance.0),
                lpszClassName: PCWSTR(cn.as_ptr()),
                hbrBackground: HBRUSH(GetStockObject(BLACK_BRUSH).0),
                ..Default::default()
            };
            RegisterClassW(&wc);
        }
        Self {
            lock_windows: HashMap::new(),
        }
    }

    /// Create full-screen black lock windows on all monitors.
    pub fn lock_all_screens(&mut self, _app: &tauri::AppHandle) -> Result<(), String> {
        unsafe {
            let cn: Vec<u16> = std::ffi::OsStr::new(LOCK_CLASS)
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();
            let mut monitors: Vec<RECT> = Vec::new();
            let _ = EnumDisplayMonitors(
                HDC::default(),
                None,
                Some(monitor_enum_proc),
                LPARAM(&mut monitors as *mut _ as isize),
            );

            if monitors.is_empty() {
                monitors.push(RECT {
                    left: GetSystemMetrics(SM_XVIRTUALSCREEN),
                    top: GetSystemMetrics(SM_YVIRTUALSCREEN),
                    right: GetSystemMetrics(SM_XVIRTUALSCREEN)
                        + GetSystemMetrics(SM_CXVIRTUALSCREEN),
                    bottom: GetSystemMetrics(SM_YVIRTUALSCREEN)
                        + GetSystemMetrics(SM_CYVIRTUALSCREEN),
                });
            }

            let hinstance = GetModuleHandleW(None).unwrap_or_default();

            for (i, r) in monitors.iter().enumerate() {
                let label = format!("lock-{}", i);
                let x = r.left;
                let y = r.top;
                let w = r.right - r.left;
                let h = r.bottom - r.top;

                let create_result = CreateWindowExW(
                    WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
                    PCWSTR(cn.as_ptr()),
                    PCWSTR::null(),
                    WS_POPUP | WS_VISIBLE,
                    x,
                    y,
                    w,
                    h,
                    HWND::default(),
                    HMENU::default(),
                    hinstance,
                    None,
                );

                if let Ok(hwnd) = create_result {
                    if !hwnd.is_invalid() {
                        let _ = SetWindowPos(
                            hwnd,
                            HWND_TOPMOST,
                            x,
                            y,
                            w,
                            h,
                            SWP_NOACTIVATE | SWP_SHOWWINDOW,
                        );
                        // Set a 1s timer for redraw
                        SetTimer(hwnd, 1, 1000, None);
                        self.lock_windows.insert(label, hwnd);
                        let _ = InvalidateRect(hwnd, None, true);
                    }
                } else {
                    eprintln!("Failed to create lock window for monitor {}", i);
                }
            }
        }
        if self.lock_windows.is_empty() {
            return Err("No lock windows created".to_string());
        }
        crate::keyboard_hook::IS_LOCKED.store(true, std::sync::atomic::Ordering::Relaxed);
        Ok(())
    }

    /// Destroy all lock windows and unlock
    pub fn unlock_all(&mut self) {
        unsafe {
            for (_, hwnd) in self.lock_windows.drain() {
                KillTimer(hwnd, 1).ok();
                DestroyWindow(hwnd).ok();
            }
        }
        crate::keyboard_hook::IS_LOCKED.store(false, std::sync::atomic::Ordering::Relaxed);
    }
}

unsafe extern "system" fn lock_window_proc(
    hwnd: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            // Fill black
            let rect = ps.rcPaint;
            let brush = CreateSolidBrush(COLORREF(0));
            FillRect(hdc, &rect, brush);
            let _ = DeleteObject(HGDIOBJ(brush.0));

            // Draw countdown text centered
            let remaining = *LOCK_REMAINING.lock().unwrap();
            let mins = remaining / 60;
            let secs = remaining % 60;
            let text = format!("{:02}:{:02}", mins, secs);
            let mut tw: Vec<u16> = std::ffi::OsStr::new(&text)
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();

            let mut cr = RECT::default();
            let _ = GetClientRect(hwnd, &mut cr);

            // Large cyan countdown centered
            let hfont = CreateFontW(
                96, 0, 0, 0, 700,
                0, 0, 0, 0, 0, 0, 0, 0,
                PCWSTR::null(),
            );
            let old_font = SelectObject(hdc, HGDIOBJ(hfont.0));
            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, COLORREF(0x00F7C34F)); // #4fc3f7 in BGR
            DrawTextW(hdc, &mut tw, &mut cr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            SelectObject(hdc, old_font);
            let _ = DeleteObject(HGDIOBJ(hfont.0));

            // Draw unlock hint if can unlock
            let can_unlock = *LOCK_CAN_UNLOCK.lock().unwrap();
            if can_unlock {
                let hint = "点击解锁";
                let mut hw: Vec<u16> = std::ffi::OsStr::new(hint)
                    .encode_wide()
                    .chain(std::iter::once(0))
                    .collect();
                let hfont2 = CreateFontW(
                    24, 0, 0, 0, 400,
                    0, 0, 0, 0, 0, 0, 0, 0,
                    PCWSTR::null(),
                );
                let old2 = SelectObject(hdc, HGDIOBJ(hfont2.0));
                SetTextColor(hdc, COLORREF(0x00F7C34F));
                let mut br = RECT {
                    left: cr.right - 200,
                    top: cr.bottom - 60,
                    right: cr.right - 10,
                    bottom: cr.bottom - 10,
                };
                DrawTextW(hdc, &mut hw, &mut br, DT_RIGHT | DT_BOTTOM | DT_SINGLELINE);
                SelectObject(hdc, old2);
                let _ = DeleteObject(HGDIOBJ(hfont2.0));
            }

            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1), // Prevent flicker on resize
        WM_TIMER => {
            let _ = InvalidateRect(hwnd, None, true);
            LRESULT(0)
        }
        WM_LBUTTONDOWN => {
            let can_unlock = *LOCK_CAN_UNLOCK.lock().unwrap();
            if can_unlock {
                let x = (lparam.0 & 0xFFFF) as i32;
                let y = ((lparam.0 >> 16) & 0xFFFF) as i32;
                let mut cr = RECT::default();
                let _ = GetClientRect(hwnd, &mut cr);
                // Bottom-right 200x60 area is unlock zone
                if x >= cr.right - 200 && y >= cr.bottom - 60 {
                    if let Some(app) = APP_HANDLE_FOR_LOCK.get() {
                        use tauri::Emitter;
                        let _ = app.emit("unlock_request", ());
                    }
                }
            }
            LRESULT(0)
        }
        WM_NCHITTEST => LRESULT(HTCLIENT as isize), // Prevent dragging
        WM_CLOSE => LRESULT(0),
        WM_DESTROY => LRESULT(0),
        _ => DefWindowProcW(hwnd, msg, wparam, lparam),
    }
}

unsafe extern "system" fn monitor_enum_proc(
    hmonitor: HMONITOR,
    _hdc: HDC,
    _lprc: *mut RECT,
    dw: LPARAM,
) -> BOOL {
    let monitors = &mut *(dw.0 as *mut Vec<RECT>);
    let mut info = MONITORINFO {
        cbSize: std::mem::size_of::<MONITORINFO>() as u32,
        ..Default::default()
    };
    if GetMonitorInfoW(hmonitor, &mut info).0 != 0 {
        monitors.push(info.rcMonitor);
    }
    TRUE
}
