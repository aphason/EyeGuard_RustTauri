use std::ffi::OsStr;
use std::os::windows::ffi::OsStrExt;
use tauri::Manager;

#[link(name = "winmm")]
extern "system" {
    fn mciSendStringW(
        lpstrCommand: *const u16,
        lpstrReturnString: *mut u16,
        uReturnLength: u32,
        hwndCallback: *mut std::ffi::c_void,
    ) -> u32;
}

fn to_wide(s: &str) -> Vec<u16> {
    OsStr::new(s)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect()
}

pub fn play_midi(file_path: &str) -> Result<(), String> {
    // Close any previously playing MIDI
    let close_cmd = to_wide("close sound");
    unsafe {
        let result = mciSendStringW(close_cmd.as_ptr(), std::ptr::null_mut(), 0, std::ptr::null_mut());
        if result != 0 {
            eprintln!("MCI close error: {} (ignored, device may not exist)", result);
        }
    }

    let open_cmd = format!("open \"{}\" type sequencer alias sound", file_path);
    let open_wide = to_wide(&open_cmd);
    let mut buf = [0u16; 256];

    let result = unsafe { mciSendStringW(open_wide.as_ptr(), buf.as_mut_ptr(), 256, std::ptr::null_mut()) };
    if result != 0 {
        eprintln!("MCI open error {} for path: {}", result, file_path);
        return Err(format!("Failed to open MIDI file: {}", file_path));
    }

    let play_cmd = to_wide("play sound");
    let result = unsafe { mciSendStringW(play_cmd.as_ptr(), std::ptr::null_mut(), 0, std::ptr::null_mut()) };
    if result != 0 {
        eprintln!("MCI play error: {}", result);
        return Err("Failed to play MIDI".to_string());
    }

    Ok(())
}

/// Get the sounds directory path relative to app resources
pub fn get_sounds_dir(app_handle: &tauri::AppHandle) -> String {
    let resource_dir = app_handle
        .path()
        .resource_dir()
        .unwrap_or_else(|_| std::path::PathBuf::from("."));
    let sounds_dir = resource_dir.join("sounds");
    sounds_dir.to_string_lossy().to_string()
}
